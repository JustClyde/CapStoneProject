# Gym Log (frontend)

## Local development

Setup local environment for the development process in the current directory `gym-log/frontend`.

### Run in a terminal

```shell
npm install 
npm start
```