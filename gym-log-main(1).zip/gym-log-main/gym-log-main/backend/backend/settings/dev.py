from backend.settings.base import *

DEBUG = True
